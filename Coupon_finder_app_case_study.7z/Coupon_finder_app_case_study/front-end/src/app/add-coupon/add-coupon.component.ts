import { Component, OnInit } from '@angular/core';
import { CouponService } from '../shared/coupon.service';
import { NgForm } from '@angular/forms';
import { Coupon } from '../shared/coupon.model';


declare var M:any;
@Component({
  selector: 'app-add-coupon',
  templateUrl: './add-coupon.component.html',
  styleUrls: ['./add-coupon.component.css'],
  providers:[CouponService]
})
export class AddCouponComponent implements OnInit {
  pageTitle: string = 'Coupon List';
  listFilter:string='';

 
  cartItemCount: number = 0;
  yourByteArray:any;
  couponAddedTocart:Coupon[];
  constructor(public couponService:CouponService) { }

  ngOnInit(): void {
    this.resetForm(); 
    this.refreshCouponList();
  }

  
  resetForm(form?:NgForm){
    if(form)
    form.reset();
    this.couponService.selectedCoupon ={
      _id:"",
    name:"",
    brand:"",
    code:null,
    description:"",
    price:null,
    imgUrl:"",
    Quantity:null,
    }
  }

  couponForm:NgForm;

  onSubmit(form:NgForm){
    if(form.value._id==""){
    this.couponService.postCoupon(form.value).subscribe((res)=> { 
     this.resetForm(form);
     this.refreshCouponList();
      M.toast({ html:'saved successfully',classes:'rounded'});
    });
  }
  else{
   this.couponService.putCoupon(form.value).subscribe((res)=> { 
     this.resetForm(form);
     this.refreshCouponList();
      M.toast({ html:'updated successfully',classes:'rounded'});
    });
  }
 }
 

 refreshCouponList(){
  this.couponService.getCouponList().subscribe((res) =>{
  this.couponService.coupons = res as Coupon[];
});
}


onEdit(coupon:Coupon){
this.couponService.selectedCoupon =coupon;
}


onDelete( _id:string, form:NgForm){
if(confirm('Are you sure to delete the record ?')==true){
this.couponService.deleteCoupon(_id).subscribe((res)=>{
this.refreshCouponList();
M.toast({ html:'Deleted successfully',classes:'rounded'});
 });
}
}
 
  

}
