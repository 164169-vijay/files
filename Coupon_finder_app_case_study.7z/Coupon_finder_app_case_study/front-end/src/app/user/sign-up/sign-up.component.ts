import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/shared/user.service';
import { NgForm } from '@angular/forms';



@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css'],
  providers:[UserService]
})
export class SignUpComponent implements OnInit {

  constructor(public userService:UserService) { }

  ngOnInit(): void {
  }
  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  showSuccesMessage:boolean;
  serverErrorMessage:string;

 onSubmit(form:NgForm){
   this.userService.postUser(form.value).subscribe(
    res => { this.showSuccesMessage=true;
    setTimeout(()=>this.showSuccesMessage=false,4000);
    this.resetForm(form);
    },
    err =>{
      if(err.status==422){
        this.serverErrorMessage=err.error.join('<br/>');
      }
      else
      this.serverErrorMessage='Something went wrong please contact admin. ';
    }
);
}



resetForm(form:NgForm){
  this.userService.selectedUser={
    fullName:'',
    email:'',
    password:''
  };
  form.resetForm();
  this.serverErrorMessage='';
}



}
