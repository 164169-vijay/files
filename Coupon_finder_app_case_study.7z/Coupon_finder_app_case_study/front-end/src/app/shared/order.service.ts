import { Injectable } from '@angular/core';
import { Observable, of, throwError, pipe} from "rxjs"
import { map, filter, catchError, mergeMap } from 'rxjs/operators';
import { OrderDetail } from './OrderDetails.model';
import{ HttpClient } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class OrderService {

  selectedOrderDetails:OrderDetail;
  orderDetails:OrderDetail[];

 public apiURL:string="http://localhost:3000/orderDetails";

  constructor(private http:HttpClient) { }

  PlaceOrder (orderDetail:OrderDetail)
  {
    return this.http.post(this.apiURL,orderDetail);
  }
}


