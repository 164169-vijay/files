import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/shared/coupon.model';
import { CouponService } from 'src/app/shared/coupon.service';
import { User } from 'src/app/shared/user.model';
import { UserService } from 'src/app/shared/user.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { OrderDetail } from 'src/app/shared/OrderDetails.model';
import { OrderItem } from 'src/app/shared/OrderItem.model';
import { OrderService } from 'src/app/shared/order.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  dafualtQuantity:number=1;
  couponAddedTocart:Coupon[];
  allTotal:number;
  orderDetail:OrderDetail;
  orderItem:OrderItem[];
 
  public globalResponse: any;

  currentUser: any;

  
  deliveryForm:FormGroup;


  userDetails:User[];

  constructor(public couponService:CouponService ,public userService: UserService ,private fb: FormBuilder, private orderService:OrderService) { }

  ngOnInit(): void {



    this.couponAddedTocart=this.couponService.getCouponFromCart();
    for (let i in this.couponAddedTocart) {
      this.couponAddedTocart[i].Quantity=1;
   }
   this.couponService.removeCouponFromCart();
   this.couponService.addCouponToCart(this.couponAddedTocart);
   this.calculteAllTotal(this.couponAddedTocart);
  
  
  

   this.GetLoggedinUserDetails();

   this.deliveryForm = this.fb.group({
    UserName:  ['', [Validators.required]],
    DeliveryAddress:['',[Validators.required]],
    Phone:['',[Validators.required]],
    Email:['',[Validators.required]],
    Message:['',[]],
    Amount:['',[Validators.required]],

  });


  this.deliveryForm.controls['Amount'].setValue(this.allTotal);
  

 
  
}



  onAddQuantity(coupon:Coupon)
  {
    //Get Product
    this.couponAddedTocart=this.couponService.getCouponFromCart();
    this.couponAddedTocart.find(p=>p._id==coupon._id).Quantity = coupon.Quantity+1;
   
  this.couponService.removeCouponFromCart();
  this.couponService.addCouponToCart(this.couponAddedTocart);
  this.calculteAllTotal(this.couponAddedTocart);
 
  this.deliveryForm.controls['Amount'].setValue(this.allTotal);
   
  }





  onRemoveQuantity(coupon:Coupon)
  {
    this.couponAddedTocart=this.couponService.getCouponFromCart();
    this.couponAddedTocart.find(p=>p._id==coupon._id).Quantity = coupon.Quantity-1;
    this.couponService.removeCouponFromCart();
    this.couponService.addCouponToCart(this.couponAddedTocart);
   
    this.calculteAllTotal(this.couponAddedTocart);

     this.deliveryForm.controls['Amount'].setValue(this.allTotal);
 
  }



  calculteAllTotal(allItems:any)
  {
    let total=0;
    for (let i in allItems) {
      total= total+(allItems[i].Quantity *allItems[i].price);
   }
   this.allTotal=total;
  }



 GetLoggedinUserDetails()
  {
    this.userService.getUserProfile().subscribe((res) =>{
      this.currentUser = res ['user'];
    });

  } 

   ConfirmOrder()
  {
    const date: Date = new Date();
 
    let orderDetail:any={};
    
    
    
    //Assigning the ordered item details

    this.orderItem=[];
    for (let i in this.couponAddedTocart) {
      this.orderItem.push({
        ID:0,
        ProductID:this.couponAddedTocart[i].code,
        ProductName:this.couponAddedTocart[i].name,
        OrderedQuantity:this.couponAddedTocart[i].Quantity,
        PerUnitPrice:this.couponAddedTocart[i].price,
        OrderID:0,
      }) ;
   }      
   
   //So now compelte object of order is
    
  

    this.orderService.PlaceOrder(orderDetail)
           .subscribe((result) => {
             this.globalResponse = result;              
           },
           error => { 
             console.log(error.message);
          
           }
         )   

       }  

  isShowDiv = true;
  isShowDiv2 = true;
   
  toggleDisplayDiv() {
    this.isShowDiv = !this.isShowDiv;
  }
  toggleDisplayDiv2() {
    this.isShowDiv2 = !this.isShowDiv2;
  }
 

}

