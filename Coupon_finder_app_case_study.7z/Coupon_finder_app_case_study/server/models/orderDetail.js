const mongoose= require('mongoose');

//const OrderItemSchema=  ();


var OrdetDetail = mongoose.model('OrdetDetail',{
 
    OrderID :{type:Number},
     CustomerId :{type:Number},
     CustomerName:{type:String},
     DeliveryAddress:{type:String},
     Phone:{type:String},
     OrderPayMethod :{type:String},
     PaymentRefrenceId :{type:String},
     OrderItem:[{
            ID :{type:Number},
            ProductID:{type:Number},
             ProductName: {type:String},
             OrderedQuantity :{type:Number},
             PerUnitPrice :{type:Number},
             OrderID :{type:Number}
             }]
    
},); 


    


module.exports ={OrdetDetail}; 