  const express =require('express');
var router= express.Router();
var {OrdetDetail} =require('../models/orderDetail.js');


// localhost:3000/OrdetDetails/
router.get('/',(req,res)=>{
    OrdetDetail.find((err,docs)=>{
        if(!err){res.send(docs);}
        else { console.log('Error in Retriving Order detail:'+ JSON.stringify( err,undefined,2 )); }
    });
}); 


router.post('/',(req,res)=>{
    
    var ordetDetail=new OrdetDetail(req.body)
  
     ordetDetail.save((err,doc)=>{
             if(!err){res.send(doc);}
             else  {console.log('Error in Player  Save:'+JSON.stringify(err,undefined,2)); }
         });
 }); 

 module.exports = router;