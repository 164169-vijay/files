package io.vijay.springboot.models;

public class AllProduct {

	private int id;
	private String productName;
	private String code;
	private String Desc;
	private String price;
	
	
	public AllProduct() {}
	
	
	public AllProduct(int id, String productName, String code, String desc, String price) {
		super();
		this.id = id;
		this.productName = productName;
		this.code = code;
		Desc = desc;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return Desc;
	}

	public void setDesc(String desc) {
		Desc = desc;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "AllProduct [id=" + id + ", productName=" + productName + ", code=" + code + ", Desc=" + Desc
				+ ", price=" + price + "]";
	}
	
	
	
	
	
	
	
	
	
}
