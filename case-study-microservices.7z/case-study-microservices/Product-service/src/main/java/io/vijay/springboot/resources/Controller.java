package io.vijay.springboot.resources;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import io.vijay.springboot.models.AllProduct;
import io.vijay.springboot.models.Product;


@RestController
@RequestMapping("/main")
public class Controller {
	
	
	@Autowired
	private RestTemplate restTemplate;

	@RequestMapping(value="/test")
	public String check() {
		return "tested";
	}
	
	
/*	@RequestMapping("/AllProducts")
	public Product get() {
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Product> prod= restTemplate.getForEntity("http://localhost:8081/findAllProducts", Product.class);
		return prod.getBody();
	}           */
	
	
	@RequestMapping("/AllProducts")
	public List<Product> get() {
		ResponseEntity<List<Product>> productResponse =
		        restTemplate.exchange("http://localhost:8081/findAllProducts",
		                    HttpMethod.GET, null, new ParameterizedTypeReference<List<Product>>() {
		            });
		List<Product> prod = productResponse.getBody();
		return prod;
	} 
	     
	@RequestMapping("/AllProducts/{id}")
	public AllProduct getitems(@PathVariable("id")String id){
		Map<String, String> var = new HashMap<>();
		var.put("id", id);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Product> AllProduct= restTemplate.getForEntity("http://localhost:8081/findAllProducts/{id}", Product.class, var );
		Product prod = AllProduct.getBody();
		return new AllProduct(prod.getId(),prod.getCode(),prod.getDesc(),prod.getPrice(),prod.getProductName());
		
	}
	
	
	
	
	
	

	
	
	
}
