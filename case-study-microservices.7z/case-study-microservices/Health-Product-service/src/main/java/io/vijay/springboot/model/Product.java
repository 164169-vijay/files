package io.vijay.springboot.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;




@Document(collection="Product")
public class Product {

	@Id
	private int id;
	private String productName;
	private String code;
	private String Desc;
	private String price;
	
	
	public Product() {}
	
	
	public Product(int id, String productName, String code, String desc, String price) {
		super();
		this.id = id;
		this.productName = productName;
		this.code = code;
		Desc = desc;
		this.price = price;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getDesc() {
		return Desc;
	}


	public void setDesc(String desc) {
		Desc = desc;
	}


	public String getPrice() {
		return price;
	}


	public void setPrice(String price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Product [id=" + id + ", productName=" + productName + ", code=" + code + ", Desc=" + Desc + ", price="
				+ price + "]";
	}
	
	
	
	
	
	
	
	
	
}
