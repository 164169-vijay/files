package io.vijay.springboot.resource;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import io.vijay.springboot.model.Product;

import io.vijay.springboot.repository.ProductRepository;
import io.vijay.springboot.service.ServiceClass;

@RestController
public class ProductController {
	
	@Autowired
	ServiceClass service;
	
	
	@RequestMapping("/hello")
	public String sayHi() {
		return "Hi" ;
	}
	
	@PostMapping("/addProduct")
	public String saveBook(@RequestBody Product product)
	{
		service.addProduct(product);
		return "Added Product with id:" +product.getId();
	}
	
	///////////
		@GetMapping("/findAllProducts")
	public Collection<Product> getAllProduct()
	{
	return	service.getAllProduct();
	
	}      
	

	
	
	////////////
	@GetMapping("/findAllProducts/{id}")
	public Product getProduct(@PathVariable int id)
	{
		return service.findone(id);
	}
	
	////////////
	@DeleteMapping("/delete/{id}")
	public String deleteProducts(@PathVariable int id)
	{
		service.deleteProd(id); 
		 return "deleted Product with id:" +id;
	}
	
	//////////
	
	
	
	
	

}
