package io.vijay.springboot.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;


import io.vijay.springboot.model.Product;
import io.vijay.springboot.repository.ProductRepository;



@Service
public class ServiceClass {

	@Autowired
	private ProductRepository repository;
	
	
	public void addProduct(Product product) {
		repository.save(product);
		
	}

	public List<Product> getAllProduct(){
		return repository.findAll();
	}
	
	
	public void updateProd(Product product) {
		repository.save(product);
	}
	
	public  void deleteProd(int id) {
		repository.deleteById(id);
	}
	
	public Product findone(int id) {
		
		return repository.findById(id).get();
		
	}
	
	
	
	
}
