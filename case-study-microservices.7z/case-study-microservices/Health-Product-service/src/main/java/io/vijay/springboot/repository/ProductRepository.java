package io.vijay.springboot.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import io.vijay.springboot.model.Product;



public interface ProductRepository extends MongoRepository<Product, Integer>{

}
