const mongoose= require('mongoose');

var Player= mongoose.model('Player',{
      Firstname:{ type:String},
      LastName:{ type:String},
      Position:{ type:String},
      Rank:{ type:Number},
      Country:{type:String},
      imgUrl:{type:String}
},); 

module.exports ={Player};