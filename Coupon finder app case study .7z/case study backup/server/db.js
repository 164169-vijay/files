const mongoose  =require('mongoose');

module.exports=mongoose;

mongoose.connect('mongodb://localhost:27017/CrudDB', { useNewUrlParser: true },(err)=>{
   if(!err)
   console.log('MongoDB connection succeded');
   else
   console.log('Error in DB '+JSON.stringify(err,undefined,2));

});


require('./models/user.model');