import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { from } from 'rxjs';
import { CouponService } from 'src/app/shared/coupon.service';
import { Coupon } from 'src/app/shared/coupon.model';
import { IAlert } from 'src/app/shared/IAlerts';
import { SharedService } from 'src/app/shared/share.service';

declare var M:any;

@Component({

  selector: 'app-coupon-list',
  templateUrl: './coupon-list.component.html',
  styleUrls: ['./coupon-list.component.css'],
  providers:[CouponService]
})
export class CouponListComponent implements OnInit {

  constructor(public couponService:CouponService,private sharedService:SharedService) { }

  pageTitle: string = 'Coupon List';
  listFilter:string='';

  public alerts: Array<IAlert> = [];
  cartItemCount: number = 0;
  yourByteArray:any;
  couponAddedTocart:Coupon[];

  ngOnInit(): void {
    this.resetForm(); 
    this.refreshCouponList();
 
  }

  resetForm(form?:NgForm){
    if(form)
    form.reset();
    this.couponService.selectedCoupon ={
      _id:"",
    name:"",
    brand:"",
    code:null,
    description:"",
    price:null,
    imgUrl:"",
    Quantity:null,
    }
  }

  couponForm:NgForm;

  onSubmit(form:NgForm){
    if(form.value._id==""){
    this.couponService.postCoupon(form.value).subscribe((res)=> { 
     this.resetForm(form);
     this.refreshCouponList();
      M.toast({ html:'saved successfully',classes:'rounded'});
    });
  }
  else{
   this.couponService.putCoupon(form.value).subscribe((res)=> { 
     this.resetForm(form);
     this.refreshCouponList();
      M.toast({ html:'updated successfully',classes:'rounded'});
    });
  }
 }
 

 refreshCouponList(){
  this.couponService.getCouponList().subscribe((res) =>{
  this.couponService.coupons = res as Coupon[];
});
}


onEdit(coupon:Coupon){
this.couponService.selectedCoupon =coupon;
}


onDelete( _id:string, form:NgForm){
if(confirm('Are you sure to delete the record ?')==true){
this.couponService.deleteCoupon(_id).subscribe((res)=>{
this.refreshCouponList();
M.toast({ html:'Deleted successfully',classes:'rounded'});
 });
}
}
 
// Below code for cart

OnAddCart(coupon:Coupon)
            {
              console.log(coupon);
              
              this.couponAddedTocart=this.couponService.getCouponFromCart();
              if(this.couponAddedTocart==null)
              {
                this.couponAddedTocart=[];
                this.couponAddedTocart.push(coupon);
                this.couponService.addCouponToCart(this.couponAddedTocart);
                this.alerts.push({
                  id: 1,
                  type: 'success',
                  message: 'Product added to cart.'
                });
                setTimeout(()=>{   
                  this.closeAlert(this.alerts);
             }, 3000);

              }
              else
              {
                let tempProduct=this.couponAddedTocart.find(p=>p._id==coupon._id);
                if(tempProduct==null)
                {
                  this.couponAddedTocart.push(coupon);
                  this.couponService.addCouponToCart(this.couponAddedTocart);
                  this.alerts.push({
                    id: 1,
                    type: 'success',
                    message: 'coupon added to cart.'
                  });
                  //setTimeout(function(){ }, 2000);
                  setTimeout(()=>{   
                    this.closeAlert(this.alerts);
               }, 3000);
                }
                else
                {
                  this.alerts.push({
                    id: 2,
                    type: 'warning',
                    message: 'Coupon already exist in cart.'
                  });
                  setTimeout(()=>{   
                    this.closeAlert(this.alerts);
               }, 3000);
                }
                
              }
              console.log(this.cartItemCount);
              this.cartItemCount=this.couponAddedTocart.length;
              // this.cartEvent.emit(this.cartItemCount);
            this.sharedService.updateCartCount(this.cartItemCount); 
            }
            public closeAlert(alert:any) {
              const index: number = this.alerts.indexOf(alert);
              this.alerts.splice(index, 1);
          }   


}
