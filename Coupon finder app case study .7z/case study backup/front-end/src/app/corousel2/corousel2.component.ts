import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corousel2',
  templateUrl: './corousel2.component.html',
  styleUrls: ['./corousel2.component.css']
})
export class Corousel2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
