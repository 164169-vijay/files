import { Component, OnInit } from '@angular/core';
import { IAlert } from 'src/app/shared/IAlerts';
import { Coupon } from 'src/app/shared/coupon.model';
import { CouponService } from 'src/app/shared/coupon.service';
import { User } from 'src/app/shared/user.model';
import { UserService } from 'src/app/shared/user.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { OrderDetail } from 'src/app/shared/OrderDetails.model';
import { OrderItem } from 'src/app/shared/OrderItem.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  dafualtQuantity:number=1;
  couponAddedTocart:Coupon[];
  allTotal:number;
  orderDetail:OrderDetail;
  orderItem:OrderItem[];
 
  public globalResponse: any;
  public alerts: Array<IAlert> = [];
  currentUser: any;

  
  deliveryForm:FormGroup;


  userDetails:User[];

  constructor(public couponService:CouponService ,public userService: UserService ,private fb: FormBuilder, ) { }

  ngOnInit(): void {
// added for getting user details
    {
      this.userService.getUserProfile().subscribe(
        res => {
          this.userDetails = res['user'];
        },
        err => { 
          console.log(err);
          
        }
      );
    } 





    this.couponAddedTocart=this.couponService.getCouponFromCart();
    for (let i in this.couponAddedTocart) {
      this.couponAddedTocart[i].Quantity=1;
   }
   this.couponService.removeCouponFromCart();
   this.couponService.addCouponToCart(this.couponAddedTocart);
   this.calculteAllTotal(this.couponAddedTocart);
  
  
  

   this.GetLoggedinUserDetails();

   this.deliveryForm = this.fb.group({
    UserName:  ['', [Validators.required]],
    DeliveryAddress:['',[Validators.required]],
    Phone:['',[Validators.required]],
    Email:['',[Validators.required]],
    Message:['',[]],
    Amount:['',[Validators.required]],

  });

  this.deliveryForm.controls['UserName'].setValue(this.currentUser["UserName"]);
  this.deliveryForm.controls['Phone'].setValue(this.currentUser["Phone"]);
  this.deliveryForm.controls['Email'].setValue(this.currentUser["Email"]);
  this.deliveryForm.controls['Amount'].setValue(this.allTotal);
  

 
  
}



  onAddQuantity(coupon:Coupon)
  {
    //Get Product
    this.couponAddedTocart=this.couponService.getCouponFromCart();
    this.couponAddedTocart.find(p=>p._id==coupon._id).Quantity = coupon.Quantity+1;
    //Find produc for which we want to update the quantity
    //let tempProd= this.productAddedTocart.find(p=>p.Id==product.Id);  
    //tempProd.Quantity=tempProd.Quantity+1;
   
    //this.productAddedTocart=this.productAddedTocart.splice(this.productAddedTocart.indexOf(product), 1)
   //Push the product for cart
   // this.productAddedTocart.push(tempProd);
  this.couponService.removeCouponFromCart();
  this.couponService.addCouponToCart(this.couponAddedTocart);
  this.calculteAllTotal(this.couponAddedTocart);
 
 /*  this.deliveryForm.controls['Amount'].setValue(this.allTotal); */
   
  }





  onRemoveQuantity(coupon:Coupon)
  {
    this.couponAddedTocart=this.couponService.getCouponFromCart();
    this.couponAddedTocart.find(p=>p._id==coupon._id).Quantity = coupon.Quantity-1;
    this.couponService.removeCouponFromCart();
    this.couponService.addCouponToCart(this.couponAddedTocart);
   
    this.calculteAllTotal(this.couponAddedTocart);

  /*   this.deliveryForm.controls['Amount'].setValue(this.allTotal);
 */
  }



  calculteAllTotal(allItems:any)
  {
    let total=0;
    for (let i in allItems) {
      total= total+(allItems[i].Quantity *allItems[i].price);
   }
   this.allTotal=total;
  }

  public closeAlert(alert: IAlert) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
 } 

 GetLoggedinUserDetails()
  {
    this.currentUser=this.userService.getUserProfile(); 
      
  
          
  } 

   ConfirmOrder()
  {
    const date: Date = new Date();
    var id=this.currentUser['Id'];
    var name=this.currentUser["UserName"];

    let orderDetail:any={};
    
    //Orderdetail is object which hold all the value, which needs to be saved into database
    orderDetail.CustomerId=this.currentUser['Id'];
    orderDetail.CustomerName=this.currentUser["UserName"];
    orderDetail.DeliveryAddress=this.deliveryForm.controls['DeliveryAddress'].value;
    orderDetail.Phone=this.deliveryForm.controls['Phone'].value;

    orderDetail.PaymentRefrenceId=id+"-"+name;
    orderDetail.OrderPayMethod="Cash On Delivery";
    
    //Assigning the ordered item details
    this.orderItem=[];
    for (let i in this.couponAddedTocart) {
      this.orderItem.push({
        ID:0,
        ProductID:this.couponAddedTocart[i].code,
        ProductName:this.couponAddedTocart[i].name,
        OrderedQuantity:this.couponAddedTocart[i].Quantity,
        PerUnitPrice:this.couponAddedTocart[i].price,
        OrderID:0,
      }) ;
   }      
   
   //So now compelte object of order is
/*    
   orderDetail.OrderItems=this.orderItem;

   this.orderService.PlaceOrder(orderDetail)
           .subscribe((result) => {
             this.globalResponse = result;              
           },
           error => { //This is error part
             console.log(error.message);
             this.alerts.push({
               id: 2,
               type: 'danger',
               message: 'Something went wrong while placing the order, Please try after sometime.'
             });
           },
           () => {
               //  This is Success part
               //console.log(this.globalResponse);
               this.alerts.push({
                 id: 1,
                 type: 'success',
                 message: 'Order has been placed succesfully.',
               });
               
               }
             )  */

       }  

  isShowDiv = true;
   
  toggleDisplayDiv() {
    this.isShowDiv = !this.isShowDiv;
  }

 

}

