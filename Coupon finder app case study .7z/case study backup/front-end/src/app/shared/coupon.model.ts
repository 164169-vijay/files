export class Coupon {
    
    _id:string;
    name:string;
    brand:String;
    code:number;
    description:String;
    price:number;
    imgUrl:String;
    Quantity:number;

}
