import { Coupon } from './coupon.model';

describe('Coupon', () => {
  it('should create an instance', () => {
    expect(new Coupon()).toBeTruthy();
  });
});
