export interface IAlert {
    id: number;
    type: string;
    message: string;
  }