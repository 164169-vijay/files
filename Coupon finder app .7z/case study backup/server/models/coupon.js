const mongoose= require('mongoose');

var Coupon = mongoose.model('Coupon',{
      name:{ type:String},
      brand:{ type:String},
      code:{ type:Number},
      description:{type:String},
      price:{ type:Number},
      imgUrl:{type:String},
      Quantity:{ type:Number},
},); 

module.exports ={Coupon};