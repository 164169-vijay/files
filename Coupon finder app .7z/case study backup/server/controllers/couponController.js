const express =require('express');
var router= express.Router();
var {Coupon} =require('../models/coupon.js');

// localhost:3000/coupons/
router.get('/',(req,res)=>{
    Coupon.find((err,docs)=>{
        if(!err){res.send(docs);}
        else { console.log('Error in Retriving Coupon:'+ JSON.stringify( err,undefined,2 )); }
    });
});

//get by id 
router.get('/:id',(req,res)=>{
      if(!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id: ${req.params.id}`);

      Coupon.findById(req.params.id,(err,doc)=>{
        if(!err){res.send(docs);}
        else { console.log('Error in Retriving Coupon:'+ JSON.stringify( err,undefined,2 )); }
    });
});

router.post('/',(req,res)=>{
   var coupon=new Coupon({
    name:req.body.name,
    brand:req.body.brand,
    code:req.body.code,
    description:req.body.description,
    price:req.body.price,
    imgUrl:req.body.imgUrl,
    Quantity:req.body.Quantity,
    });
    coupon.save((err,doc)=>{
            if(!err){res.send(doc);}
            else  {console.log('Error in Coupon  Save:'+JSON.stringify(err,undefined,2)); }
        });
});

router.put('/:id', (req, res, next)=>{
    Coupon.findOneAndUpdate({_id : req.params.id},{
        $set:{
            name:req.body.name,
            brand:req.body.brand,
            code:req.body.code,
            description:req.body.description,
            price:req.body.price,
            imgUrl:req.body.imgUrl,
        }
    },
    function(err, result){
        if (err){
            res.json(err)
        }
        else{
            res.json(result)
        }
    })
})

router.delete( '/:id',function(req,res,next) {
    Coupon.findOneAndDelete({_id:req.params.id}).then(function(coupon){ 
     res.send(coupon);
    });
      res.send({type:'Delete'});     
  });


module.exports = router;