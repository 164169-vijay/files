const express =require('express');
var router= express.Router();


var {Player} =require('../models/player.js');

// localhost:3000/players/
router.get('/',(req,res)=>{
    Player.find((err,docs)=>{
        if(!err){res.send(docs);}
        else { console.log('Error in Retriving Player:'+ JSON.stringify( err,undefined,2 )); }
    });
});

//get by id
router.get('/:id',(req,res)=>{
      if(!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id: ${req.params.id}`);

      Player.findById(req.params.id,(err,doc)=>{
        if(!err){res.send(docs);}
        else { console.log('Error in Retriving Player:'+ JSON.stringify( err,undefined,2 )); }
    });
});

router.post('/',(req,res)=>{
   var player=new Player({
    Firstname:req.body.Firstname,
    LastName:req.body.LastName,
    Position:req.body.Position,
    Rank:req.body.Rank,
    Country:req.body.Country,
    imgUrl:req.body.imgUrl,
    });
    player.save((err,doc)=>{
            if(!err){res.send(doc);}
            else  {console.log('Error in Player  Save:'+JSON.stringify(err,undefined,2)); }
        });
});


router.put('/:id', (req, res, next)=>{
    Player.findOneAndUpdate({_id : req.params.id},{
        $set:{
           
            Firstname:req.body.Firstname,
            LastName:req.body.LastName,
            Position:req.body.Position,
            Rank:req.body.Rank,
            Country:req.body.Country,
            imgUrl:req.body.imgUrl,
        }
    },
    function(err, result){
        if (err){
            res.json(err)
        }
        else{
            res.json(result)
        }
    })
})

router.delete( '/:id',function(req,res,next) {
    Player.findOneAndDelete({_id:req.params.id}).then(function(player){ 
     res.send(player);
    });
      res.send({type:'Delete'});     
  });


module.exports = router;