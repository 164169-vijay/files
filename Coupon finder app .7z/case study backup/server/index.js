
const {mongoose} =require('./db.js');
require('./config/passportConfig');
require('./config/config');
require('./db');

const express =require('express');
const bodyParser=require('body-parser');
const cors=require('cors');

const passport = require('passport');
const rtsIndex=require('./routes/index.routes');

var couponController=require('./controllers/couponController.js');

var app =express();


app.use(bodyParser.json());
app.use(passport.initialize());


var playerController=require('./controllers/playerContorllers.js');



app.use(cors({   origin:'http://localhost:4200' }));
app.listen( 3000, () => console.log('server started at port :3000'));

app.use('/players',playerController); 
app.use('/api',rtsIndex);
app.use('/coupons',couponController); 

//error handler
app.use((err,req,res,next)=>{
    if(err.name=='validationError'){
        var valError=[];
        Object.keys(err.errors).forEach(key=>valError.push(err.errors[key].message));
        res.status(422).send(valErrors)
    }
});
