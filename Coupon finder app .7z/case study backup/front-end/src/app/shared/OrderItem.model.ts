export interface OrderItem
{
         ID :number
         ProductID:number
         ProductName :string
         OrderedQuantity :number
         PerUnitPrice :number
         OrderID :number
}