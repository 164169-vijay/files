import { Injectable } from '@angular/core';
import{ HttpClient } from '@angular/common/http';
import{Coupon} from './coupon.model';
import { from, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class CouponService {
  selectedCoupon:Coupon;
  coupons:Coupon[];

  readonly baseURL = 'http://localhost:3000/coupons';

  constructor(private http:HttpClient) { }

  postCoupon(coupon:Coupon){
    return this.http.post(this.baseURL,coupon);
 }

  getCouponList(){
    return this.http.get(this.baseURL);
  }
   
  putCoupon(coupon:Coupon){
   return this.http.put(this.baseURL+`/${coupon._id}`,coupon);
  }
  
  deleteCoupon(_id: string){
   return this.http.delete(this.baseURL+`/${_id}`);
  }
  

  // Below code  for cart  
  addCouponToCart(coupons: any) {
    localStorage.setItem("coupon", JSON.stringify(coupons));
  }
  getCouponFromCart() {
    //return localStorage.getItem("product");
    return JSON.parse(localStorage.getItem('coupon'));
  }
  removeCouponFromCart() {
    return localStorage.removeItem('coupon');
  }
  errorHandler(error: Response) {  
    console.log(error);  
    return throwError(error);  
} 





  
}
