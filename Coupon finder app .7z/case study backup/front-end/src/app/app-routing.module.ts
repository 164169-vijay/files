import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProductListComponent } from './product/product-list/product-list.component';
import { SignUpComponent } from './user/sign-up/sign-up.component';
import { UserComponent } from './user/user.component';
import { SignInComponent } from './user/sign-in/sign-in.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { AuthGuard } from './auth/auth.guard';
import { CartComponent } from './shopping_cart/cart/cart.component';
import { AddCouponComponent } from './add-coupon/add-coupon.component';


const routes: Routes = [
  
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutUsComponent },
 /*   { path: 'cart', component: CartComponent },  */
  { path: 'addCoupon', component: AddCouponComponent },
  { path: 'product', component: ProductListComponent },
  {
     path:'signup', component:UserComponent,
     children:[{ path:'',component:SignUpComponent}]

  },
  {
    path:'login', component:UserComponent,
    children:[{ path:'',component:SignInComponent}]
 },
 {
  path:'userprofile', component:UserProfileComponent, canActivate:[AuthGuard]
 }
 ,
 {
  path:'', redirectTo:'/home' , pathMatch:'full',
 
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }